/*Name: Lawrence Wang
 * Date: Jan 18
 * Title: Backgammon
 * Description: The class that contains the game
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Backgammon extends JPanel implements ActionListener, MouseListener{
	private BufferedImage backgammonBoard;
	private BufferedImage redPiece;
	private BufferedImage bluePiece;
	private BufferedImage clickable;
	private BufferedImage option;
	private JButton roll;
	private JLabel yourTurn;
	private JLabel cpuTurn;	
	private JLabel cpuRoll;
	private JLabel youWin;
	private JLabel cpuWins;
	private JButton endTurn;
	private JButton showMoves;
	private JButton endCpuTurn;
	private int randomPiece;
	private int randomDie;
	private boolean playersTurn = false;
	private boolean rolled = false;
	private boolean movable = false;
	private static BufferedImage one;
	private static JLabel diceOne;
	private static JLabel diceOne2;
	private static JLabel diceOne3;
	private static JLabel diceOne4;
	private static BufferedImage two;
	private static JLabel diceTwo;
	private static JLabel diceTwo2;
	private static JLabel diceTwo3;
	private static JLabel diceTwo4;
	private static BufferedImage three;
	private static JLabel diceThree;
	private static JLabel diceThree2;
	private static JLabel diceThree3;
	private static JLabel diceThree4;
	private static BufferedImage four;
	private static JLabel diceFour;
	private static JLabel diceFour2;
	private static JLabel diceFour3;
	private static JLabel diceFour4;
	private static BufferedImage five;
	private static JLabel diceFive;
	private static JLabel diceFive2;
	private static JLabel diceFive3;
	private static JLabel diceFive4;
	private static BufferedImage six;
	private static JLabel diceSix;
	private static JLabel diceSix2;
	private static JLabel diceSix3;
	private static JLabel diceSix4;
	private static JLabel board;
	private static int[] dice = {0,0};
	private static JLabel[] clickables = new JLabel[15];
	private static int[][] spaces = new int[26][2];//24 triangles, 2nd dimension contains one element 
													//	which holds the current colour of pieces on it
													//and one element which holds the number of pieces
	private static int[] middleBar = new int[2];
	private static JLabel[] pieces = new JLabel[30];
	private static JLabel clickedPiece;
	private static JLabel[] options = new JLabel[4];
	private static int[] diceCombos = new int[4];
//	private static Backgammon single_instance = null;
	
	Backgammon() {
		//SET THE DEFAULT PANEL THINGS
		this.addMouseListener(this);
		this.setLayout(null);
		this.setBackground(new Color(10,108,3));//pool table green
		
		
		gameSetup();
		playerTurn();

		
		}
	public void playerTurn() {
		playersTurn=true;
		this.add(yourTurn);
		this.add(roll);
		drawClickables();
		redrawPieces();
	}
	public void computerTurn() {
		
		playersTurn = false;
		add(cpuTurn);
		rollDice();
		displayDice();
		add(cpuRoll);
		showMoves.setBounds(685,180,180,50);
		add(showMoves);
	}
	public void drawClickables() {
		int clickableCounter = 0;
		for(int i=0;i<15;i++) {
			clickables[i].setBounds(0,0,0,0);//clear clickables
		}
		if(middleBar[0]!=0) {
			clickables[0].setBounds(307,255,40,40);
		}
		else {
			for(int i=0;i<24;i++) {
				if(spaces[i][0] ==1) {
					if(i <= 11) {
						clickables[clickableCounter].setBounds(570-47*i,400,40,40);
						add(clickables[clickableCounter]);
						clickableCounter++;
					}
					if(i>=12) {
						clickables[clickableCounter].setBounds(53+47*(i-12),50,40,40);
						add(clickables[clickableCounter]);
						clickableCounter++;
					}
				}
			}
		}
	}
	public void gameSetup() {//called only once, to create the Array of pieces and fill the board with pieces
		yourTurn = new JLabel("YOUR TURN");
		yourTurn.setFont(new Font("Verdana", Font.PLAIN, 28));
		yourTurn.setBounds(690,40,180,50);
		cpuTurn = new JLabel("CPU TURN");
		cpuTurn.setFont(new Font("Verdana", Font.PLAIN, 28));
		cpuTurn.setBounds(700,40,180,50);
		cpuRoll = new JLabel("Computer Rolled: ");
		cpuRoll.setFont(new Font("Verdana",Font.PLAIN, 14));
		cpuRoll.setBounds(680,80,180,50);
		showMoves = new JButton("Show CPU Moves");
		showMoves.addActionListener(this);
		showMoves.setBounds(685,180,180,50);
		roll = new JButton("Roll the dice!");
		roll.addActionListener(this);
		roll.setBounds(685,120,180,50);
		endTurn = new JButton("END TURN");
		endTurn.addActionListener(this);
		endTurn.setBounds(685,180,180,50);
		endCpuTurn = new JButton("END CPU TURN");
		endCpuTurn.addActionListener(this);
		endCpuTurn.setBounds(685,180,180,50);
		youWin = new JLabel("YOU WIN");
		youWin.setFont(new Font("Verdana", Font.PLAIN, 28));
		youWin.setBounds(690,40,180,50);
		cpuWins = new JLabel("CPU WINS");
		cpuWins.setFont(new Font("Verdana", Font.PLAIN, 28));
		cpuWins.setBounds(690,40,180,50);
		
		try {
			redPiece =ImageIO.read(new File("backgammonFiles/redPiece.png"));
		} catch (IOException e) {
		}
		try {
			bluePiece =ImageIO.read(new File("backgammonFiles/bluePiece.png"));
		} catch (IOException e) {
		}
		try {
			clickable =ImageIO.read(new File("backgammonFiles/clickable.png"));
		} catch (IOException e) {
		}
		try {
			option =ImageIO.read(new File("backgammonFiles/option.png"));
		} catch (IOException e) {
		}
		for(int i = 0;i<15;i++) {
			pieces[i] = new JLabel(new ImageIcon(redPiece));
		}
		for(int i = 15;i<30;i++) {
			pieces[i] = new JLabel(new ImageIcon(bluePiece));
		}
		for(int i = 0;i<15;i++) {
			clickables[i] = new JLabel(new ImageIcon(clickable));
		}
		for(int i = 0;i<4;i++) {
			options[i] = new JLabel(new ImageIcon(option));
		}
		spaces[0][0] = 1;//first triangle is controlled by red
		spaces[0][1] = 2;//2 pieces on first triangle
		spaces[11][0] = 1;
		spaces[11][1] = 5;
		spaces[16][0] = 1;
		spaces[16][1] = 3;
		spaces[18][0] = 1;
		spaces[18][1] = 5;
		spaces[24][0] = 1;
		
		spaces[23][0] = 2;//last triangle controlled by blue(computer)
		spaces[23][1] = 2;
		spaces[12][0] = 2;
		spaces[12][1] = 5;
		spaces[7][0] = 2;
		spaces[7][1] = 3;
		spaces[5][0] = 2;
		spaces[5][1] = 5;
		spaces[25][0] = 2;
	}
	public void redrawPieces() {
		int bluePieceCount = 15;
		int redPieceCount = 0;
		for(int i=0;i<24;i++) {//through each triangle
			if(spaces[i][0] == 1) {//if space is red
				if(spaces[i][1] == 0) {
					spaces[i][0] = 0;
				}
				for(int j=0;j<spaces[i][1];j++) {//for all pieces on that space
					if(i <= 11) {
						pieces[redPieceCount].setBounds(570-47*i,400-30*j,40,40);
						add(pieces[redPieceCount]);
						redPieceCount++;
					}
					if(i>=12) {
						pieces[redPieceCount].setBounds(53+47*(i-12),50+30*j,40,40);
						add(pieces[redPieceCount]);
						redPieceCount++;
					}
				}
			}
			if(spaces[i][0] == 2) {
				if(spaces[i][1] == 0) {
					spaces[i][0] = 0;
				}
				for(int j=0;j<spaces[i][1];j++) {//for all pieces on that space
					if(i <= 11) {
						pieces[bluePieceCount].setBounds(570-47*i,400-30*j,40,40);
						add(pieces[bluePieceCount]);
						bluePieceCount++;
					}
					if(i>=12) {
						if(bluePieceCount ==30) {
							bluePieceCount--;
						}
						pieces[bluePieceCount].setBounds(53+47*(i-12),50+30*j,40,40);
						add(pieces[bluePieceCount]);
						bluePieceCount++;
					}
				}
			}
		}
		int redCount= 0;
		for(int i=0;i<spaces[24][1];i++) {
			pieces[redPieceCount].setBounds(630,50+redCount*19,40,40);
			add(pieces[redPieceCount]);
			redPieceCount++;
			redCount++;
		}
		int blueCount =0;
		for(int i=0;i<spaces[25][1];i++) {
			pieces[bluePieceCount].setBounds(630,400-blueCount*19,40,40);
			add(pieces[bluePieceCount]);
			bluePieceCount++;
			blueCount++;
		}
		if(redCount ==15) {
			diceOne.setBounds(10000,10000,50,50);
			diceOne2.setBounds(10000,10000,50,50);
			diceOne3.setBounds(10000,10000,50,50);
			diceOne4.setBounds(10000,10000,50,50);
			diceTwo.setBounds(10000,10000,50,50);
			diceTwo2.setBounds(10000,10000,50,50);
			diceTwo3.setBounds(10000,10000,50,50);
			diceTwo4.setBounds(10000,10000,50,50);
			diceThree.setBounds(10000,10000,50,50);
			diceThree2.setBounds(10000,10000,50,50);
			diceThree3.setBounds(10000,10000,50,50);
			diceThree4.setBounds(10000,10000,50,50);
			diceFour.setBounds(10000,10000,50,50);
			diceFour2.setBounds(10000,10000,50,50);
			diceFour3.setBounds(10000,10000,50,50);
			diceFour4.setBounds(10000,10000,50,50);
			diceFive.setBounds(10000,10000,50,50);
			diceFive2.setBounds(10000,10000,50,50);
			diceFive3.setBounds(10000,10000,50,50);
			diceFive4.setBounds(10000,10000,50,50);
			diceSix.setBounds(10000,10000,50,50);
			diceSix2.setBounds(10000,10000,50,50);
			diceSix3.setBounds(10000,10000,50,50);
			diceSix4.setBounds(10000,10000,50,50);
			remove(yourTurn);
			remove(endTurn);
			add(youWin);
			MyGame.redraw();
		}
		if(blueCount ==15) {
			diceOne.setBounds(10000,10000,50,50);
			diceOne2.setBounds(10000,10000,50,50);
			diceOne3.setBounds(10000,10000,50,50);
			diceOne4.setBounds(10000,10000,50,50);
			diceTwo.setBounds(10000,10000,50,50);
			diceTwo2.setBounds(10000,10000,50,50);
			diceTwo3.setBounds(10000,10000,50,50);
			diceTwo4.setBounds(10000,10000,50,50);
			diceThree.setBounds(10000,10000,50,50);
			diceThree2.setBounds(10000,10000,50,50);
			diceThree3.setBounds(10000,10000,50,50);
			diceThree4.setBounds(10000,10000,50,50);
			diceFour.setBounds(10000,10000,50,50);
			diceFour2.setBounds(10000,10000,50,50);
			diceFour3.setBounds(10000,10000,50,50);
			diceFour4.setBounds(10000,10000,50,50);
			diceFive.setBounds(10000,10000,50,50);
			diceFive2.setBounds(10000,10000,50,50);
			diceFive3.setBounds(10000,10000,50,50);
			diceFive4.setBounds(10000,10000,50,50);
			diceSix.setBounds(10000,10000,50,50);
			diceSix2.setBounds(10000,10000,50,50);
			diceSix3.setBounds(10000,10000,50,50);
			diceSix4.setBounds(10000,10000,50,50);
			remove(cpuTurn);
			remove(endCpuTurn);
			add(cpuWins);
			MyGame.redraw();
		}
		for(int i=0;i<middleBar[0];i++) {
			pieces[redPieceCount].setBounds(307,255+17*i,40,40);
			add(pieces[redPieceCount]);
			redPieceCount++;
		}
		for(int i=0;i<middleBar[1];i++) {
			pieces[bluePieceCount].setBounds(307,205-17*i,40,40);
			add(pieces[bluePieceCount]);
			bluePieceCount++;
		}
	}
	public void rollDice(){
		dice[0] = 0;
		dice[1] = 0;
//		dice[2] = 0;
//		dice[3] = 0;
		dice[0] = (int)(Math.random() * 6) + 1;
		dice[1] = (int)(Math.random() * 6) + 1;
//		if(dice[0] == dice[1]) {
//			dice[2] = dice[0];
//			dice[3] = dice[0];
//		}
//		else {
//			dice[2] = 0;
//			dice[3] = 0;
//		}
//		for(int i =0;i<4;i++) {
//			System.out.print(dice[i]);
//		}
}
	public void displayDice() {
		try { //import number one on dice
			one = ImageIO.read(new File("backgammonFiles/one.png"));
		} catch (IOException e1) {
		}
		try { //import number two on dice
			two = ImageIO.read(new File("backgammonFiles/two.png"));
		} catch (IOException e1) {
		}
		try { //import number three on dice
			three = ImageIO.read(new File("backgammonFiles/three.png"));
		} catch (IOException e1) {
		}
		try { //import number four on dice
			four = ImageIO.read(new File("backgammonFiles/four.png"));
		} catch (IOException e1) {
		}
		try { //import number five on dice
			five = ImageIO.read(new File("backgammonFiles/five.png"));
		} catch (IOException e1) {
		}
		try { //import number six on dice
			six = ImageIO.read(new File("backgammonFiles/six.png"));
		} catch (IOException e1) {
		}
		diceOne = new JLabel(new ImageIcon(one));
		diceOne2 = new JLabel(new ImageIcon(one));
		diceOne3 = new JLabel(new ImageIcon(one));
		diceOne4 = new JLabel(new ImageIcon(one));
		diceTwo = new JLabel(new ImageIcon(two));
		diceTwo2 = new JLabel(new ImageIcon(two));
		diceTwo3 = new JLabel(new ImageIcon(two));
		diceTwo4 = new JLabel(new ImageIcon(two));
		diceThree = new JLabel(new ImageIcon(three));
		diceThree2 = new JLabel(new ImageIcon(three));
		diceThree3 = new JLabel(new ImageIcon(three));
		diceThree4 = new JLabel(new ImageIcon(three));
		diceFour = new JLabel(new ImageIcon(four));
		diceFour2 = new JLabel(new ImageIcon(four));
		diceFour3 = new JLabel(new ImageIcon(four));
		diceFour4 = new JLabel(new ImageIcon(four));
		diceFive = new JLabel(new ImageIcon(five));
		diceFive2 = new JLabel(new ImageIcon(five));
		diceFive3 = new JLabel(new ImageIcon(five));
		diceFive4 = new JLabel(new ImageIcon(five));
		diceSix = new JLabel(new ImageIcon(six));
		diceSix2 = new JLabel(new ImageIcon(six));
		diceSix3 = new JLabel(new ImageIcon(six));
		diceSix4 = new JLabel(new ImageIcon(six));
		if(dice[0]==dice[1]) {
			if(dice[0]==1){
				
				diceOne.setBounds(675, 120, 50, 50);
				this.add(diceOne);
				
				
				diceOne2.setBounds(725, 120, 50, 50);
				this.add(diceOne2);
				
				
//				diceOne3.setBounds(775, 120, 50, 50);
//				this.add(diceOne3);
//				
//				
//				diceOne4.setBounds(825, 120, 50, 50);
//				this.add(diceOne4);
				MyGame.redraw();
			}
			if(dice[0]==2){
				
				
				diceTwo.setBounds(675, 120, 50, 50);
				this.add(diceTwo);
				
				
				diceTwo2.setBounds(725, 120, 50, 50);
				this.add(diceTwo2);
				
				
//				diceTwo3.setBounds(775, 120, 50, 50);
//				this.add(diceTwo3);
//				
//				
//				diceTwo4.setBounds(825, 120, 50, 50);
//				this.add(diceTwo4);
				MyGame.redraw();
			}
			if(dice[0]==3) {
				
				
				diceThree.setBounds(675, 120, 50, 50);
				this.add(diceThree);
				
				
				diceThree2.setBounds(725, 120, 50, 50);
				this.add(diceThree2);
				
				
//				diceThree3.setBounds(775, 120, 50, 50);
//				this.add(diceThree3);
//				
//				
//				diceThree4.setBounds(825, 120, 50, 50);
//				this.add(diceThree4);
				MyGame.redraw();
			}
			if(dice[0]==4) {
				
				
				diceFour.setBounds(675, 120, 50, 50);
				this.add(diceFour);
				
				
				diceFour2.setBounds(725, 120, 50, 50);
				this.add(diceFour2);
				
				
//				diceFour3.setBounds(775, 120, 50, 50);
//				this.add(diceFour3);
//				
//				
//				diceFour4.setBounds(825, 120, 50, 50);
//				this.add(diceFour4);
				MyGame.redraw();
			}
			if(dice[0]==5) {
				
				
				diceFive.setBounds(675, 120, 50, 50);
				this.add(diceFive);
				
				
				diceFive2.setBounds(725, 120, 50, 50);
				this.add(diceFive2);
				
//				diceFive3.setBounds(775, 120, 50, 50);
//				this.add(diceFive3);
//				
//				diceFive4.setBounds(825, 120, 50, 50);
//				this.add(diceFive4);
				MyGame.redraw();
			}
			if(dice[0]==6) {
				
				
				diceSix.setBounds(675, 120, 50, 50);
				this.add(diceSix);
				
				
				diceSix2.setBounds(725, 120, 50, 50);
				this.add(diceSix2);
				
				
//				diceSix3.setBounds(775, 120, 50, 50);
//				this.add(diceSix3);
//				
//				
//				diceSix4.setBounds(825, 120, 50, 50);
//				this.add(diceSix4);
				MyGame.redraw();
			}
			
		}

		else {
			for(int i = 0;i<2;i++) {
				if(dice[i]==1) {
					
					try { //import number two on dice
						one = ImageIO.read(new File("backgammonFiles/one.png"));
					} catch (IOException e1) {
					}
					diceOne = new JLabel(new ImageIcon(one));
					diceOne.setBounds(675+50*i, 120, 50, 50);
					this.add(diceOne);
					
					MyGame.redraw();
				}
				if(dice[i]==2) {
					try { //import number two on dice
						two = ImageIO.read(new File("backgammonFiles/two.png"));
					} catch (IOException e1) {
					}
					diceTwo = new JLabel(new ImageIcon(two));
					diceTwo.setBounds(675+50*i, 120, 50, 50);
					this.add(diceTwo);
					MyGame.redraw();
				}
				if(dice[i]==3) {
					try { //import number three on dice
						three = ImageIO.read(new File("backgammonFiles/three.png"));
					} catch (IOException e1) {
					}
					diceThree = new JLabel(new ImageIcon(three));
					diceThree.setBounds(675+50*i, 120, 50, 50);
					this.add(diceThree);
					MyGame.redraw();
				}
				if(dice[i]==4) {
					try { //import number four on dice
						four = ImageIO.read(new File("backgammonFiles/four.png"));
					} catch (IOException e1) {
					}
					diceFour = new JLabel(new ImageIcon(four));
					diceFour.setBounds(675+50*i, 120, 50, 50);
					this.add(diceFour);
					MyGame.redraw();
				}
				if(dice[i]==5) {
					try { //import number five on dice
						five = ImageIO.read(new File("backgammonFiles/five.png"));
					} catch (IOException e1) {
					}
					diceFive = new JLabel(new ImageIcon(five));
					diceFive.setBounds(675+50*i, 120, 50, 50);
					this.add(diceFive);
					MyGame.redraw();
				}
				if(dice[i]==6) {
					try { //import number six on dice
						six = ImageIO.read(new File("backgammonFiles/six.png"));
					} catch (IOException e1) {
					}
					diceSix = new JLabel(new ImageIcon(six));
					diceSix.setBounds(675+50*i, 120, 50, 50);
					this.add(diceSix);
					MyGame.redraw();
				}

			}
		}
		}

//	public static Backgammon Singleton()
//    {
//        // To ensure only one instance is created
//        if (single_instance == null) {
//            single_instance = new Backgammon();
//        }
//        return single_instance;
//    }	
	
//	public void addComponent(Component c, int x, int y, int width, int height) {
//		c.setBounds(x,y,width,height);
//		add(c);
//	}
	@Override
	public void actionPerformed(ActionEvent e){  
		if(e.getSource()==roll) {
			remove(roll);
			rollDice();
			displayDice();
		}
		if(e.getSource()==endTurn) {
			diceOne.setBounds(10000,10000,50,50);
			diceOne2.setBounds(10000,10000,50,50);
			diceOne3.setBounds(10000,10000,50,50);
			diceOne4.setBounds(10000,10000,50,50);
			diceTwo.setBounds(10000,10000,50,50);
			diceTwo2.setBounds(10000,10000,50,50);
			diceTwo3.setBounds(10000,10000,50,50);
			diceTwo4.setBounds(10000,10000,50,50);
			diceThree.setBounds(10000,10000,50,50);
			diceThree2.setBounds(10000,10000,50,50);
			diceThree3.setBounds(10000,10000,50,50);
			diceThree4.setBounds(10000,10000,50,50);
			diceFour.setBounds(10000,10000,50,50);
			diceFour2.setBounds(10000,10000,50,50);
			diceFour3.setBounds(10000,10000,50,50);
			diceFour4.setBounds(10000,10000,50,50);
			diceFive.setBounds(10000,10000,50,50);
			diceFive2.setBounds(10000,10000,50,50);
			diceFive3.setBounds(10000,10000,50,50);
			diceFive4.setBounds(10000,10000,50,50);
			diceSix.setBounds(10000,10000,50,50);
			diceSix2.setBounds(10000,10000,50,50);
			diceSix3.setBounds(10000,10000,50,50);
			diceSix4.setBounds(10000,10000,50,50);
			for(int i=0;i<15;i++) {
				clickables[i].setBounds(10000,10000,50,50);
			}
			remove(endTurn);
			remove(yourTurn);
			MyGame.redraw();
			computerTurn();
		}
		if(e.getSource()==endCpuTurn) {
			diceOne.setBounds(10000,10000,50,50);
			diceOne2.setBounds(10000,10000,50,50);
			diceOne3.setBounds(10000,10000,50,50);
			diceOne4.setBounds(10000,10000,50,50);
			diceTwo.setBounds(10000,10000,50,50);
			diceTwo2.setBounds(10000,10000,50,50);
			diceTwo3.setBounds(10000,10000,50,50);
			diceTwo4.setBounds(10000,10000,50,50);
			diceThree.setBounds(10000,10000,50,50);
			diceThree2.setBounds(10000,10000,50,50);
			diceThree3.setBounds(10000,10000,50,50);
			diceThree4.setBounds(10000,10000,50,50);
			diceFour.setBounds(10000,10000,50,50);
			diceFour2.setBounds(10000,10000,50,50);
			diceFour3.setBounds(10000,10000,50,50);
			diceFour4.setBounds(10000,10000,50,50);
			diceFive.setBounds(10000,10000,50,50);
			diceFive2.setBounds(10000,10000,50,50);
			diceFive3.setBounds(10000,10000,50,50);
			diceFive4.setBounds(10000,10000,50,50);
			diceSix.setBounds(10000,10000,50,50);
			diceSix2.setBounds(10000,10000,50,50);
			diceSix3.setBounds(10000,10000,50,50);
			diceSix4.setBounds(10000,10000,50,50);
			remove(endCpuTurn);
			remove(cpuRoll);
			remove(cpuTurn);
			MyGame.redraw();
			playerTurn();
		}
		if(e.getSource()==showMoves) {
			movable = true;
			int times = 0;
			check:{
			for(int i = 0;i<2;i++) {//check if movable is true
				if(middleBar[1]!=0) {
					if(middleBar[1] == 1) {
						if(dice[i]!=0&&spaces[24-dice[i]][0]==1&&spaces[24-dice[i]][1]==1) {
							movable = true;
							break check;
						}
						if(dice[i]!=0&&(spaces[24-dice[i]][0]==2||spaces[24-dice[i]][0]==0)){
							movable = true;
							break check;
						}
						movable = false;
					}
					if(middleBar[1]>1) {
						if(dice[0]==dice[1]) {
							if(spaces[24-dice[0]][0] == 0||spaces[24-dice[0]][0] == 2||(spaces[24-dice[0]][0] == 1&&spaces[24-dice[0]][1] == 1)) {
								movable = true;
								break check;
							}
							else {
								movable = false;
								redrawPieces();
								break check;
							}
						}
						else {
							for(int j=0;j<2;j++) {//if 1/2 works
								if(spaces[24-dice[j]][0] == 0||spaces[24-dice[j]][0] == 2||(spaces[24-dice[j]][0] == 1&&spaces[24-dice[j]][1] == 1)) {
									middleBar[1]--;
									if(spaces[24-dice[j]][0]==2||spaces[24-dice[j]][0]==0) {
										spaces[24-dice[j]][1]++;
									}
									else {
										middleBar[0]++;
									}
									spaces[24-dice[j]][0] = 2;
									
								}
							}
							movable = false;
							redrawPieces();
							break check;
						}
					}
					
				}
				else {
					boolean possible1 = false;
					boolean possible2 = false;
					for(int j=0;j<24;j++) {
						if(spaces[j][0]==2) {
							if(dice[0]!=0&&j-dice[0]>=0&&(spaces[j-dice[0]][0]==0||spaces[j-dice[0]][0]==2||spaces[j-dice[0]][1]==1&&spaces[j-dice[0]][0]==1)) {
								possible1 = true;
							}
							if(dice[1]!=0&&j-dice[1]>=0&&(spaces[j-dice[1]][0]==0||spaces[j-dice[1]][0]==2||spaces[j-dice[1]][1]==1&&spaces[j-dice[1]][0]==1)) {
								possible2 = true;
							}
							if(possible1 == true &&possible2 == true) {
								movable = true;
								break check;
							}
							c:{
							for(int k=06;k<24;k++) {
								if(spaces[k][0]==2) {
									break c;
								}
							}
							
							if(dice[i]!=0&&j-dice[i]<0) {//if dice + any piece extends border, movable true and move pieces
								spaces[j][1]--;
								if(spaces[j][1]==0) {
									spaces[j][0]=0;
								}
								spaces[25][0]=2;
								spaces[25][1]++;
								System.out.println("25:"+spaces[25][1]);
								dice[i]=0;
								if(spaces[25][1]==15) {
									movable = false;
									break check;
								}
								redrawPieces();
							}
							}
							redrawPieces();
						}
					}
					movable = false;
					if(dice[0]!=0 ||dice[1]!=0) {
						movable = true;
					}
				}
			}
			}
			MyGame.redraw();
			System.out.println(movable);
			
			while(movable==true&&(dice[0]!=0||dice[1]!=0)) {
				randomPiece = 15+(int)(Math.random()*15);
				randomDie = (int)(Math.random()*2);
				if(middleBar[1]!=0) {
					
					if(dice[randomDie]!=0&&(spaces[24-dice[randomDie]][0]==0||spaces[24-dice[randomDie]][0]==2)) {
						middleBar[1]--;
						spaces[24-dice[randomDie]][0]= 2;
						spaces[24-dice[randomDie]][1]++;
						dice[randomDie]=0;
					}
					if(dice[randomDie]!=0&&(spaces[24-dice[randomDie]][0]==1&&spaces[24-dice[randomDie]][1]==1) ){
						middleBar[1]--;
						middleBar[0]++;
						spaces[24-dice[randomDie]][0]=2;
						dice[randomDie]=0;
					}
					MyGame.redraw();
					redrawPieces();
				}
				else {
					if(dice[randomDie]!=0&&(pieces[randomPiece].getY()==50||pieces[randomPiece].getY()==80||pieces[randomPiece].getY()==110||pieces[randomPiece].getY()==140||pieces[randomPiece].getY()==170||pieces[randomPiece].getY()==200||pieces[randomPiece].getY()==230||pieces[randomPiece].getY()==260||pieces[randomPiece].getY()==290||pieces[randomPiece].getY()==320)) {
						if(spaces[12+(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0] == 2||spaces[12+(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0] == 0) {//if random piece is moved a random number of spaces mentioned on a certain die and is moved onto a blue or neutral space
							spaces[12+(pieces[randomPiece].getX()-53)/47][1]--;
							spaces[12+(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0]=2;
							spaces[12+(pieces[randomPiece].getX()-53)/47-dice[randomDie]][1]++;
							
							if(spaces[12+(pieces[randomPiece].getX()-53)/47][1] == 0) {
								spaces[12+(pieces[randomPiece].getX()-53)/47][0]=0;
							}
							dice[randomDie]=0;
						}
						else if(spaces[12+(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0] == 1&&spaces[12+(pieces[randomPiece].getX()-53)/47-dice[randomDie]][1]==1) {
							spaces[12+(pieces[randomPiece].getX()-53)/47][1]--;
							spaces[12+(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0]=2;
							middleBar[0]++;
					
							if(spaces[12+(pieces[randomPiece].getX()-53)/47][1] == 0) {
								spaces[12+(pieces[randomPiece].getX()-53)/47][0]=0;
							}
							dice[randomDie]=0;
						}
						redrawPieces();
					}
					else if(pieces[randomPiece].getY()==400||pieces[randomPiece].getY()==370||pieces[randomPiece].getY()==340||pieces[randomPiece].getY()==310||pieces[randomPiece].getY()==280||pieces[randomPiece].getY()==250||pieces[randomPiece].getY()==220||pieces[randomPiece].getY()==190||pieces[randomPiece].getY()==160||pieces[randomPiece].getY()==130) {
						
						if((11-(pieces[randomPiece].getX()-53)/47-dice[randomDie]>=0)&&(spaces[11-(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0] == 2||spaces[11-(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0] == 0)) {//if random piece is moved a random number of spaces mentioned on a certain die and is moved onto a blue or neutral space
							spaces[11-(pieces[randomPiece].getX()-53)/47][1]--;
							spaces[11-(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0]=2;
							spaces[11-(pieces[randomPiece].getX()-53)/47-dice[randomDie]][1]++;
							
							if(spaces[11-(pieces[randomPiece].getX()-53)/47][1] == 0) {
								spaces[11-(pieces[randomPiece].getX()-53)/47][0]=0;
							}
							dice[randomDie]=0;
						}
						else if((11-(pieces[randomPiece].getX()-53)/47-dice[randomDie]>=0)&&spaces[11-(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0] == 1&&spaces[11-(pieces[randomPiece].getX()-53)/47-dice[randomDie]][1] == 1){
							spaces[11-(pieces[randomPiece].getX()-53)/47][1]--;
							spaces[11-(pieces[randomPiece].getX()-53)/47-dice[randomDie]][0]=2;
							middleBar[0]++;

							if(spaces[11-(pieces[randomPiece].getX()-53)/47][1] == 0) {
								spaces[11-(pieces[randomPiece].getX()-53)/47][0]=0;
							}
							dice[randomDie]=0;
						}
						
						
					}
					redrawPieces();
					MyGame.redraw();
				}
				
			}	
			
			System.out.println("NoMoves");
				remove(showMoves);
				add(endCpuTurn);
} 
}
//	@Override
//	public void paint(Graphics g) {
//		super.paint(g);
//		g.drawImage(backgammonBoard,0, 0, 300, 300, null);
//	}
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		try {//import board 
			backgammonBoard = ImageIO.read(new File("backgammonFiles/backgammon.png"));
		} catch (IOException e) {
		}
		g.drawImage(backgammonBoard,30, 40, 600, 412, null);
		g.drawRect(675, 40, 200, 412);
		g.setColor(Color.white);
		g.fillRect(675, 40, 200, 412);
		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
	}
	public void showOptions(JLabel j) {//shows the options for where the piece could go

		for(int i=0;i<4;i++) {
			options[i].setBounds(10000,10000,40,150);
		}
		
		
		if(middleBar[0]!= 0) {
			System.out.println(middleBar[0]);
			for(int i = 0;i<2;i++) {
				if(dice[i]>0&&(spaces[dice[i]-1][0]==0||spaces[dice[i]-1][0]==1||(spaces[dice[i]-1][0]==2&&spaces[dice[i]-1][1]==1))&&dice[i]<=12) {
					options[i].setBounds(623-47*dice[i], 290,40,150);
				}
				if(dice[i]>0&&(spaces[dice[i]-1][0]==0||spaces[dice[i]-1][0]==1||(spaces[dice[i]-1][0]==2&&spaces[dice[i]-1][1]==1))&&dice[i]>12) {
					options[i].setBounds(53+47*(dice[i]-13), 50,40,150);
				}
			}
			
			MyGame.redraw();
			redrawPieces();
			if(options[0].getX()==10000&&options[1].getX()==10000&&options[2].getX()==10000&&options[3].getX()==10000) {
				add(endTurn);
			}
		}
		
		else{
	 		for(int i = 0;i<2;i++) {
				if(dice[i] != 0 && j.getY() == 400 && j.getX()-47*dice[i] >=53) {//stays in bottom row
					if(spaces[11-(((j.getX()-53)/47)-dice[i])][0] !=2 ||(spaces[11-(((j.getX()-53)/47)-dice[i])][0]==2&&spaces[11-(((j.getX()-53)/47)-dice[i])][1]==1)) {
						options[i].setBounds(j.getX()-47*dice[i], 290,40,150);
	//					System.out.println("That:"+(j.getX()-47*dice[i]));
						add(options[i]);
						MyGame.redraw();
				}}
				if(dice[i] != 0 && j.getY() == 400 && j.getX()-47*dice[i] <53&&(6+47*(dice[i]-((j.getX()-53)/47))<=570)) {
					if(spaces[11-(((j.getX()-53)/47)-dice[i])][0] != 2||(spaces[11-(((j.getX()-53)/47)-dice[i])][0]==2&&spaces[11-(((j.getX()-53)/47)-dice[i])][1]==1)) {
						options[i].setBounds(6+47*(dice[i]-((j.getX()-53)/47)), 50, 40, 150);
	//					System.out.println("This:"+(6+47*(dice[i]-((j.getX()-53)/47))));
						add(options[i]);
						MyGame.redraw();
					}
				}
				if(dice[i] != 0 && j.getY() == 50&&dice[i]*47+j.getX()<=570) {
					if(spaces[12+(((j.getX()-53)/47)+dice[i])][0] !=2 ||(spaces[12+(((j.getX()-53)/47)+dice[i])][0]==2&&spaces[12+(((j.getX()-53)/47)+dice[i])][1]==1)){
						options[i].setBounds(j.getX()+47*dice[i],50,40,150);
	//					System.out.println("Three:"+(j.getX()+47*dice[i]));
						add(options[i]);
						MyGame.redraw();
					}
				}
			}
		
		}
		thing:{
			for(int i=0;i<18;i++) {
				if(spaces[i][0]==1) {
					break thing;
				}
			}
			
			
		for(int i=0;i<2;i++) {
			if(12+(clickedPiece.getX()-53)/47+dice[i]>=24) {
				if(options[0].getX()== 10000) {
					options[0].setBounds(630, 50, 40, 150);
				}
				else if(options[1].getX()== 10000) {
					options[1].setBounds(630, 50, 40, 150);
				}
			}
		}
		}
		a:{
		if(middleBar[0]==0) {
			for(int i=0;i<2;i++) {
				for(int j1=0;j1<24;j1++) {
					b:{
						for(int k=0;k<18;k++) {
							if(spaces[j1][0]==1) {
								break b;
							}
						}
						break a;
					}
					if(dice[i]!=0&&(dice[i]!=0&&spaces[j1][0]==1&&(spaces[j1+dice[i]][0]==0||spaces[j1+dice[i]][0]==1||(spaces[j1+dice[i]][0]==2&&spaces[j1+dice[i]][1]==1)))) {
						break a;
					}
				}
			}
			System.out.println("MidBar"+middleBar[0]);
			add(endTurn);
			MyGame.redraw();
		}
		
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
		// TODO Auto-generated method stub
		for(int i = 0; i<15;i++) {//if the mouse click is within the x and y coordinates of any of the clickables
			if(e.getX()>clickables[i].getX()&&
					e.getX()<clickables[i].getX()+40&&
					e.getY()>clickables[i].getY()&&
					e.getY()<clickables[i].getY()+40) {
				for(int j=0;j<15;j++) {//find the clicked piece
					if(pieces[j].getX()==clickables[i].getX()&&pieces[j].getY()==clickables[i].getY() && e.getX()>pieces[j].getX()&&
					e.getX()<pieces[j].getX()+40&&
					e.getY()>pieces[j].getY()&&
					e.getY()<pieces[j].getY()+40) {
						clickedPiece = pieces[j];
						
						
					}
					
				}
				showOptions(clickables[i]);
				
			}
		}
		for(int i =0;i<4;i++) {//when option clicked
			int spacesMoved = 0;
			if(middleBar[0]!=0&&e.getX()>options[i].getX()&&
					e.getX()<options[i].getX()+40&&
					e.getY()>options[i].getY()&&
					e.getY()<options[i].getY()+150) {
				if(options[i].getY()==290&&spaces[11-((options[i].getX()-53)/47)][0]==2&&(spaces[11-((options[i].getX()-53)/47)][1]==1)){
					middleBar[0]--;
					middleBar[1]++;
					spaces[11-(options[i].getX()-53)/47][0]=1;
					spacesMoved = 12-(options[i].getX()-53)/47;
					System.out.println("A: " +spacesMoved);
				}
				else if(options[i].getY()==290&&(spaces[11-((options[i].getX()-53)/47)][0]==1||spaces[11-((options[i].getX()-53)/47)][0]==0)) {
					middleBar[0]--;
					
					spaces[11-(options[i].getX()-53)/47][0]=1;
					spaces[11-(options[i].getX()-53)/47][1]++;
					spacesMoved = 12-(options[i].getX()-53)/47;
					System.out.println("B: " +spacesMoved);
				}
				if(options[i].getY()==50&&(spaces[12+((options[i].getX()-53)/47)][0]==2&&spaces[12+((options[i].getX()-53)/47)][1]==1)) {
					middleBar[0]--;
					middleBar[1]++;
					spaces[12+(options[i].getX()-53)/47][0] =1;
					spacesMoved = 13+(options[i].getX()-53)/47;
					System.out.println("C: "+spacesMoved);
				}
				else if(options[i].getY()==50&&(spaces[12+((options[i].getX()-53)/47)][0]==0||spaces[12+((options[i].getX()-53)/47)][0]==1)) {
					middleBar[0]--;
					spaces[12+(options[i].getX()-53)/47][0] =1;
					spaces[12+(options[i].getX()-53)/47][1]++;
					spacesMoved = 13+(options[i].getX()-53)/47;
					System.out.println("D:"+spacesMoved);
				}
				MyGame.redraw();
				if(dice[0] == dice[1]&&spacesMoved!=0) {
					for(int k=1;k>-1;k--) {
						spacesMoved-=dice[k];
//						System.out.println("Piece"+clickedPiece);
//						System.out.println("Moved:"+spacesMoved);
						dice[k] =0;
						if(spacesMoved == 0) {
							break;
						}
					}
				}
				
				if(dice[0]!=dice[1]&&spacesMoved!=0) {
					for(int l=0;l<2;l++) {
						if(dice[l]==spacesMoved) {
							spacesMoved-=dice[l];
							dice[l] = 0;
							break;
						}
					}
//					if(spacesMoved!=0) {
//						dice[0] = 0;
//						dice[1] = 0;
//						spacesMoved = 0;
//					}
				}
//				dice[0] = 0;
//				System.out.println("Tea:"+clickedPiece.getX());
				for(int j=0;j<4;j++) {
					options[j].setBounds(10000,10000,40,150);//un-display all options
				}
				
				drawClickables();
				redrawPieces();
				
				if(dice[0]==0&&dice[1]==0) {
					add(endTurn);
					diceOne.setBounds(10000,10000,50,50);
					diceOne2.setBounds(10000,10000,50,50);
					diceOne3.setBounds(10000,10000,50,50);
					diceOne4.setBounds(10000,10000,50,50);
					diceTwo.setBounds(10000,10000,50,50);
					diceTwo2.setBounds(10000,10000,50,50);
					diceTwo3.setBounds(10000,10000,50,50);
					diceTwo4.setBounds(10000,10000,50,50);
					diceThree.setBounds(10000,10000,50,50);
					diceThree2.setBounds(10000,10000,50,50);
					diceThree3.setBounds(10000,10000,50,50);
					diceThree4.setBounds(10000,10000,50,50);
					diceFour.setBounds(10000,10000,50,50);
					diceFour2.setBounds(10000,10000,50,50);
					diceFour3.setBounds(10000,10000,50,50);
					diceFour4.setBounds(10000,10000,50,50);
					diceFive.setBounds(10000,10000,50,50);
					diceFive2.setBounds(10000,10000,50,50);
					diceFive3.setBounds(10000,10000,50,50);
					diceFive4.setBounds(10000,10000,50,50);
					diceSix.setBounds(10000,10000,50,50);
					diceSix2.setBounds(10000,10000,50,50);
					diceSix3.setBounds(10000,10000,50,50);
					diceSix4.setBounds(10000,10000,50,50);
					
					
				}
				MyGame.redraw();
			}
			else if(e.getX()>options[i].getX()&&
					e.getX()<options[i].getX()+40&&
					e.getY()>options[i].getY()&&
					e.getY()<options[i].getY()+150) {
				
				if(options[i].getY()==290&&spaces[11-((options[i].getX()-53)/47)][0]==2&&(spaces[11-((options[i].getX()-53)/47)][1]==1)){
					 middleBar[1]++;
					 spaces[11-((options[i].getX()-53)/47)][0] = 1;
					 spaces[11-((clickedPiece.getX()-53)/47)][1]--;
					 if(spaces[11-((clickedPiece.getX()-53)/47)][1]==0) {
							spaces[11-((clickedPiece.getX()-53)/47)][0] = 0;
						}
					 spacesMoved = (11-((options[i].getX()-53)/47))-(11-((clickedPiece.getX()-53)/47));
				}
				else if(options[i].getY()==290&&(spaces[11-((options[i].getX()-53)/47)][0]==1||spaces[11-((options[i].getX()-53)/47)][0]==0)) {//if selected option was bottom row and currently red or empty
					spaces[11-((options[i].getX()-53)/47)][0]=1;
					spaces[11-((options[i].getX()-53)/47)][1]++;
					if(clickedPiece.getY()==400) {
						spaces[11-((clickedPiece.getX()-53)/47)][1]--;
						if(spaces[11-((clickedPiece.getX()-53)/47)][1]==0) {
							spaces[11-((clickedPiece.getX()-53)/47)][0] = 0;
						}
						spacesMoved = (11-((options[i].getX()-53)/47))-(11-((clickedPiece.getX()-53)/47));
//						System.out.println(spacesMoved);
					}
//					if(clickedPiece.getY()==50) {
//						spaces[12+((clickedPiece.getX())-53)/47][1]--;
//						if(spaces[12+((clickedPiece.getX()-53)/47)][1]==0) {
//							spaces[12+((clickedPiece.getX()-53)/47)][0] = 0;
//						}
//						spacesMoved = (11-((options[i].getX()-53)/47))-();
//					}
				}
				if(options[i].getX()==650) {
					spaces[24][1]++;
					spaces[12+(clickedPiece.getX()-53)/47][1]--;
					if(spaces[12+((clickedPiece.getX()-53)/47)][1]==0) {
						spaces[12+((clickedPiece.getX()-53)/47)][0] = 0;
					}
				}
				if(options[i].getY()==50&&(spaces[12+((options[i].getX()-53)/47)][0]==2&&spaces[12+((options[i].getX()-53)/47)][1]==1)){
					spaces[12+((options[i].getX()-53)/47)][0]=1;
					middleBar[1]++;
					if(clickedPiece.getY()==400) {
						spaces[11-((clickedPiece.getX()-53)/47)][1]--;
						if(spaces[11-((clickedPiece.getX()-53)/47)][1]==0) {
							spaces[11-((clickedPiece.getX()-53)/47)][0] = 0;
						}
						spacesMoved = (12+((options[i].getX()-53)/47))-(11-((clickedPiece.getX()-53)/47));
					}
					if(clickedPiece.getY()==50) {
						spaces[12+((clickedPiece.getX())-53)/47][1]--;
						if(spaces[12+((clickedPiece.getX()-53)/47)][1]==0) {
							spaces[12+((clickedPiece.getX()-53)/47)][0] = 0;
						}
						spacesMoved = (12+((options[i].getX()-53)/47))-(12+((clickedPiece.getX()-53)/47));
//						System.out.println(spacesMoved);
					}
				}
				else if(options[i].getY()==50&&(spaces[12+((options[i].getX()-53)/47)][0]==0||spaces[12+((options[i].getX()-53)/47)][0]==1)) {//if selected option was top row
					spaces[12+((options[i].getX()-53)/47)][0]=1;
					spaces[12+((options[i].getX()-53)/47)][1]++;
					if(clickedPiece.getY()==400) {
						spaces[11-((clickedPiece.getX()-53)/47)][1]--;
						if(spaces[11-((clickedPiece.getX()-53)/47)][1]==0) {
							spaces[11-((clickedPiece.getX()-53)/47)][0] = 0;
						}
						spacesMoved = (12+((options[i].getX()-53)/47))-(11-((clickedPiece.getX()-53)/47));
//						System.out.println(spacesMoved); 
					}
					if(clickedPiece.getY()==50) {
						spaces[12+((clickedPiece.getX())-53)/47][1]--;
						if(spaces[12+((clickedPiece.getX()-53)/47)][1]==0) {
							spaces[12+((clickedPiece.getX()-53)/47)][0] = 0;
						}
						spacesMoved = (12+((options[i].getX()-53)/47))-(12+((clickedPiece.getX()-53)/47));
//						System.out.println(spacesMoved);
					}
				}
				if(dice[0] == dice[1]&&spacesMoved!=0) {
					for(int k=0;k<2;k++) {
						spacesMoved-=dice[k];
//						System.out.println("Piece"+clickedPiece);
//						System.out.println("Moved:"+spacesMoved);
						dice[k] =0;
						if(spacesMoved <= 0) {
							break;
						}
					}
				}
				cleardice:{
				if(dice[0]!=dice[1]&&spacesMoved!=0) {
					for(int l=0;l<2;l++) {
						if(dice[l]==spacesMoved) {
							spacesMoved-=dice[l];
							dice[l] = 0;
							break cleardice;
						}
					}
					if(dice[0]<=dice[1]) {
						dice[1] = 0;
						break cleardice;
					}
					if(dice[1]<=dice[0]) {
						dice[0] = 0;
						break cleardice;
					}
				}
				}
//				dice[0] = 0;
//				System.out.println("Tea:"+clickedPiece.getX());
				for(int j=0;j<4;j++) {
					options[j].setBounds(10000,10000,40,150);//un-display all options
				}
				
				drawClickables();
				redrawPieces();
				
				if(dice[0]==0&&dice[1]==0) {
					add(endTurn);
					diceOne.setBounds(10000,10000,50,50);
					diceOne2.setBounds(10000,10000,50,50);
					diceOne3.setBounds(10000,10000,50,50);
					diceOne4.setBounds(10000,10000,50,50);
					diceTwo.setBounds(10000,10000,50,50);
					diceTwo2.setBounds(10000,10000,50,50);
					diceTwo3.setBounds(10000,10000,50,50);
					diceTwo4.setBounds(10000,10000,50,50);
					diceThree.setBounds(10000,10000,50,50);
					diceThree2.setBounds(10000,10000,50,50);
					diceThree3.setBounds(10000,10000,50,50);
					diceThree4.setBounds(10000,10000,50,50);
					diceFour.setBounds(10000,10000,50,50);
					diceFour2.setBounds(10000,10000,50,50);
					diceFour3.setBounds(10000,10000,50,50);
					diceFour4.setBounds(10000,10000,50,50);
					diceFive.setBounds(10000,10000,50,50);
					diceFive2.setBounds(10000,10000,50,50);
					diceFive3.setBounds(10000,10000,50,50);
					diceFive4.setBounds(10000,10000,50,50);
					diceSix.setBounds(10000,10000,50,50);
					diceSix2.setBounds(10000,10000,50,50);
					diceSix3.setBounds(10000,10000,50,50);
					diceSix4.setBounds(10000,10000,50,50);
					
					
				}
				MyGame.redraw();
				
				
			}
			
		}
		
		
	
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
}
/* Name: Lawrence
 * Date: Dec 18
 * Title: GUIQ2
 * Description: Question 2 of the gui exercises. A button and a label at the top.
 *  A 10x10 grid of buttons with images in them, 
 *  and 3 buttons that fill out the bottom
 */

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GUIQ2 extends JFrame{    
   BufferedImage image;
   Icon icon;
	GUIQ2(){    
		try {
			image = ImageIO.read(new File("backgammonFiles/one.png"));//import image, create imageicon
		} catch (IOException e) {
		}
	    icon = new ImageIcon(image);
	    
		JPanel upperPart = new JPanel();
		JLabel jlabel = new JLabel("My new game...."); //create upper part with button and label
	    upperPart.add(new JButton(icon));
		upperPart.add(jlabel);
	    
		JPanel buttonPanel = new JPanel();//create a panel for the grid of buttons
	    for(int i = 0;i<100;i++) {
	    buttonPanel.add(new JButton(icon));
	    }
	    buttonPanel.setLayout(new GridLayout(10,10,1,1));  //make buttonpanel a gridlayout
	    
	    
	    JPanel lowerPart = new JPanel();//create the lower panel with buttons
	    lowerPart.setLayout(new GridLayout(1,3));
	    lowerPart.setPreferredSize(new Dimension(675, 50));
	    lowerPart.add(new JButton("aaaa"));
	    lowerPart.add(new JButton("bbbb"));
	    lowerPart.add(new JButton("cccc"));
	    this.add(upperPart);
	    this.add(buttonPanel);
	    this.add(lowerPart);
	}    
	public static void main(String[]args) {//frame creation and customization
		GUIQ2 m = new GUIQ2();
		m.setLayout(new FlowLayout());
		m.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		m.setResizable(false);
		m.setTitle("My New Game");
		m.pack();
		m.setSize(675,800);
		m.setVisible(true);
	}
}    
